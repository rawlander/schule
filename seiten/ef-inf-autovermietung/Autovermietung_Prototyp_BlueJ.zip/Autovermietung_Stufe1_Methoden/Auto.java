/**
 * Ein E-Mietwagen der Autovermietung "Palm Bay Rentals".
 *
 * Stufe 1: Auftraege und Anfragen.
 * Wie der Marsrover kann das Auto fahren (fahre()) und Fragen
 * beantworten (istVoll()). Neu ist: Wir sehen jetzt selbst,
 * was sich das Auto merkt - seine Attribute.
 *
 * Der Ocean Boulevard ist eine gerade Strasse. Block 0 ist die Garage.
 * Der Akku wird in Balken gemessen (wie die Anzeige im Auto).
 */
public class Auto
{
    // Attribute: das "Gedaechtnis" des Autos
    private String name;
    private int position;
    private int akku;
    private int akkuGroesse;

    /**
     * Erzeugt ein Auto mit leerem Akku in der Garage (Block 0).
     *
     * @param pName Modellname des Autos
     * @param pAkkuGroesse maximale Anzahl Akku-Balken
     */
    public Auto(String pName, int pAkkuGroesse)
    {
        name = pName;
        akkuGroesse = pAkkuGroesse;
        position = 0;
        akku = 0;
    }

    // ---------- Getter (Anfragen nach Attributen) ----------

    /** @return Modellname des Autos */
    public String gibName()
    {
        return name;
    }

    /** @return aktueller Block auf dem Ocean Boulevard (0 = Garage) */
    public int gibPosition()
    {
        return position;
    }

    /** @return Anzahl geladener Akku-Balken */
    public int gibAkku()
    {
        return akku;
    }

    /** @return maximale Anzahl Akku-Balken */
    public int gibAkkuGroesse()
    {
        return akkuGroesse;
    }

    // ---------- Auftraege ----------

    /**
     * Das Auto faehrt einen Block weiter.
     * (Beim Rover: fahre() - ein Feld weiter.)
     */
    public void fahre()
    {
        // TODO Aufgabe 1.1: Erhoehe die Position um 1.
    }

    /**
     * Das Auto faehrt zurueck in die Garage.
     * Beispiel fuer einen Auftrag, der ein Attribut setzt.
     */
    public void kehreZurueck()
    {
        position = 0;
    }

    /**
     * Laedt einen Akku-Balken, falls der Akku nicht voll ist.
     */
    public void ladeBalken()
    {
        // TODO Aufgabe 1.3: Wenn der Akku nicht voll ist, erhoehe akku um 1.
    }

    /**
     * Verbraucht einen Akku-Balken, falls der Akku nicht leer ist.
     */
    public void verbraucheBalken()
    {
        // TODO Aufgabe 1.4: Wenn der Akku nicht leer ist, verringere akku um 1.
    }

    /**
     * Laedt so lange Balken, bis der Akku voll ist.
     * (Beim Rover: while (!huegelVorhanden("vorne")) { fahre(); })
     */
    public void ladeKomplett()
    {
        // TODO Aufgabe 1.5: Lade mit einer while-Schleife Balken, solange der Akku nicht voll ist.
    }

    // ---------- Anfragen ----------

    /**
     * Beispiel fuer eine Anfrage.
     *
     * @return true, wenn das Auto in der Garage steht
     */
    public boolean istInGarage()
    {
        return position == 0;
    }

    /**
     * @return true, wenn alle Akku-Balken geladen sind
     */
    public boolean istVoll()
    {
        // TODO Aufgabe 1.2: Gib zurueck, ob akku die akkuGroesse erreicht hat.
        return false;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * @return true, wenn kein Balken mehr geladen ist
     */
    public boolean istLeer()
    {
        // TODO Aufgabe 1.2: Gib zurueck, ob akku 0 ist.
        return false;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * Gibt alle Daten des Autos auf der Konsole aus.
     */
    public void anzeigen()
    {
        System.out.println(name + ": Block " + position
            + ", Akku " + akku + "/" + akkuGroesse + " Balken");
    }
}
