Projekt: Palm Bay Rentals (Autovermietung) - Stufe 1: Auftraege und Anfragen (Methoden, Attribute, if, while)
Kurs: Informatik EF (NRW), Bischoefliches St.-Josef-Gymnasium Bocholt
Fassung: Schuelerfassung mit Luecken

Vom Marsrover zur Autovermietung: Was ihr mit dem Rover in Greenfoot gelernt habt
(Auftraege, Anfragen, Parameter, Rueckgabe), wendet ihr hier in reinem Java an.

SO ARBEITEST DU
1. Klasse kompilieren (Uebersetzen).
2. Rechtsklick auf Pruefstand -> allesPruefen(): Im Terminal erscheint die Testtabelle.
3. Die Stellen mit "TODO Aufgabe x.y" in Reihenfolge bearbeiten, nach jeder Aufgabe neu pruefen.
4. Ziel (Plateau): alle Tests ausser "Expert" bestehen.

AUFGABEN STUFE 1 (Klasse Auto)
1.1 fahre(): Position um 1 erhoehen.                          (Rover: fahre())
1.2 istVoll() und istLeer(): Anfragen mit return.             (Rover: gesteinVorhanden())
1.3 ladeBalken(): nur laden, wenn der Akku nicht voll ist (if).
1.4 verbraucheBalken(): nur verbrauchen, wenn der Akku nicht leer ist (if).
1.5 ladeKomplett(): while-Schleife bis voll.                  (Rover: while (!huegelVorhanden("vorne")))
Ausprobieren: Rechtsklick auf Auto -> new Auto("Flamingo GT", 3), dann Methoden am Objekt
aufrufen und mit "Inspizieren" die Attribute beobachten.

