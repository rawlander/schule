/**
 * Pruefstand fuer Stufe 1.
 *
 * Rechtsklick auf die Klasse Pruefstand -> allesPruefen() ausfuehren.
 * Im Terminalfenster erscheint eine Testtabelle wie im Rover-Labor:
 * Testfall, erwartet, erhalten, ok.
 */
public class Pruefstand
{
    private static int bestanden;
    private static int gesamt;

    /**
     * Fuehrt alle Testfaelle der Stufe 1 aus.
     */
    public static void allesPruefen()
    {
        start("Stufe 1: Auftraege und Anfragen");
        Auto a = new Auto("Flamingo GT", 3);
        pruefe("neues Auto: istInGarage()", true, a.istInGarage());
        pruefe("neues Auto: istLeer()", true, a.istLeer());
        pruefe("neues Auto: istVoll()", false, a.istVoll());

        a.fahre();
        a.fahre();
        pruefe("2x fahre(): gibPosition()", 2, a.gibPosition());
        pruefe("2x fahre(): istInGarage()", false, a.istInGarage());

        a.ladeBalken();
        pruefe("1x ladeBalken(): gibAkku()", 1, a.gibAkku());
        pruefe("1 von 3 Balken: istLeer()", false, a.istLeer());

        a.ladeBalken();
        a.ladeBalken();
        a.ladeBalken();
        pruefe("4x laden bei 3 Balken: gibAkku()", 3, a.gibAkku());
        pruefe("3 von 3 Balken: istVoll()", true, a.istVoll());

        a.verbraucheBalken();
        pruefe("1x verbraucheBalken(): gibAkku()", 2, a.gibAkku());

        Auto leer = new Auto("Beach Buggy", 2);
        leer.verbraucheBalken();
        pruefe("leeren Akku verbrauchen: gibAkku()", 0, leer.gibAkku());

        Auto gross = new Auto("Night Cruiser", 7);
        if (new Auto("Test", 0).istVoll())
        {
            gross.ladeKomplett();
            pruefe("ladeKomplett() bei 7 Balken", 7, gross.gibAkku());
        }
        else
        {
            pruefe("ladeKomplett(): erst istVoll() (1.2) loesen!", 7, "-");
        }
        ende();
    }

    // ---------- Hilfsmethoden fuer die Testtabelle ----------

    private static void start(String pTitel)
    {
        bestanden = 0;
        gesamt = 0;
        System.out.println("=== " + pTitel + " ===");
        System.out.println(spalte("Testfall", 42) + spalte("erwartet", 10) + spalte("erhalten", 10) + "ok");
    }

    private static void pruefe(String pFall, Object pErwartet, Object pErhalten)
    {
        gesamt++;
        boolean ok = String.valueOf(pErwartet).equals(String.valueOf(pErhalten));
        if (ok)
        {
            bestanden++;
        }
        System.out.println(spalte(pFall, 42) + spalte(String.valueOf(pErwartet), 10)
            + spalte(String.valueOf(pErhalten), 10) + (ok ? "ja" : "NEIN"));
    }

    private static void ende()
    {
        System.out.println("--> " + bestanden + " von " + gesamt + " Tests bestanden");
        System.out.println();
    }

    private static String spalte(String pText, int pBreite)
    {
        String t = pText;
        while (t.length() < pBreite)
        {
            t = t + " ";
        }
        return t + " ";
    }

    /** Start ausserhalb von BlueJ. */
    public static void main(String[] args)
    {
        allesPruefen();
    }
}
