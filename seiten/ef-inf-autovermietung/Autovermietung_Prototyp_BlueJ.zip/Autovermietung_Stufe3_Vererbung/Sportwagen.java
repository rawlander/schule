/**
 * Ein Sportwagen - das Aushaengeschild von "Palm Bay Rentals".
 *
 * Musterklasse fuer Stufe 3: So sieht eine Unterklasse aus.
 * Vergleiche mit der Klasse Van, die du selbst ergaenzt.
 */
public class Sportwagen extends Fahrzeug
{
    private int ps;
    private boolean dachOffen;

    /**
     * Erzeugt einen Sportwagen in der Garage, Dach geschlossen.
     *
     * @param pName Modellname
     * @param pGeschwindigkeit Reisegeschwindigkeit in km/h
     * @param pPs Motorleistung in PS
     */
    public Sportwagen(String pName, int pGeschwindigkeit, int pPs)
    {
        // super(...) ruft den Konstruktor von Fahrzeug auf - immer als Erstes!
        super(pName, pGeschwindigkeit);
        ps = pPs;
        dachOffen = false;
    }

    /** @return Motorleistung in PS */
    public int gibPs()
    {
        return ps;
    }

    /** @return true, wenn das Dach offen ist */
    public boolean istDachOffen()
    {
        return dachOffen;
    }

    /** Oeffnet oder schliesst das Dach (Cabrio-Modus). */
    public void wechsleDach()
    {
        dachOffen = !dachOffen;
    }

    /**
     * Pflicht-Override: gibTyp() war in Fahrzeug abstrakt.
     *
     * @return "Sportwagen"
     */
    @Override
    public String gibTyp()
    {
        return "Sportwagen";
    }

    /**
     * Override MIT super: Grundmiete plus 1 Euro je 2 PS.
     *
     * @return Tagesmiete in Euro
     */
    @Override
    public int berechneMiete()
    {
        return super.berechneMiete() + ps / 2;
    }

    /** Override MIT super: erst die Fahrzeugdaten, dann PS und Dach. */
    @Override
    public void anzeigen()
    {
        super.anzeigen();
        System.out.println("   " + ps + " PS, Dach " + (dachOffen ? "offen" : "zu"));
    }
}
