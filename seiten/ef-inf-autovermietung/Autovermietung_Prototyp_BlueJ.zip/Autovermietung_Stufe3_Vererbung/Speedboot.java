/**
 * Ein Speedboot zum Mieten - fuer Touren an der Kueste.
 *
 * Besonderheit: Boote haben einen eigenen Tarif (Bootsfuehrerschein,
 * Versicherung). Die Tagesmiete wird deshalb OHNE super komplett neu
 * berechnet.
 */
public class Speedboot extends Fahrzeug
{
    private int sprit;
    private int tankGroesse;

    /**
     * Erzeugt ein Speedboot mit leerem Tank am Steg (Block 0).
     *
     * @param pName Name des Fahrzeuges
     * @param pGeschwindigkeit Geschwindigkeit in km/h
     * @param pTankGroesse Tankgroesse in Litern
     */
    public Speedboot(String pName, int pGeschwindigkeit, int pTankGroesse)
    {
        super(pName, pGeschwindigkeit);
        tankGroesse = pTankGroesse;
        sprit = 0;
    }

    /** @return Sprit im Tank in Litern */
    public int gibSprit()
    {
        return sprit;
    }

    /**
     * Tankt hoechstens pLiter, soweit Platz ist.
     *
     * @param pLiter gewuenschte Menge
     * @return tatsaechlich getankte Menge
     */
    public int tanken(int pLiter)
    {
        int rein = pLiter;
        if (sprit + rein > tankGroesse)
        {
            rein = tankGroesse - sprit;
        }
        sprit = sprit + rein;
        return rein;
    }

    @Override
    public String gibTyp()
    {
        return "Speedboot";
    }

    /**
     * Override OHNE super: Boots-Pauschale 200 Euro plus 2 Euro je Liter im Tank.
     * Die Grundmiete von Fahrzeug gilt fuer Boote nicht.
     *
     * @return Tagesmiete in Euro
     */
    @Override
    public int berechneMiete()
    {
        // TODO Aufgabe 3.7: Berechne 200 + 2 * sprit, diesmal OHNE super.
        return 0;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    @Override
    public void anzeigen()
    {
        super.anzeigen();
        System.out.println("   Sprit: " + sprit + "/" + tankGroesse + " Liter");
    }
}
