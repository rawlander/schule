Projekt: Palm Bay Rentals (Autovermietung) - Stufe 3: Vererbung (abstrakte Oberklasse, super, Override)
Kurs: Informatik EF (NRW), Bischoefliches St.-Josef-Gymnasium Bocholt
Fassung: Schuelerfassung mit Luecken

Vom Marsrover zur Autovermietung: Was ihr mit dem Rover in Greenfoot gelernt habt
(Auftraege, Anfragen, Parameter, Rueckgabe), wendet ihr hier in reinem Java an.

SO ARBEITEST DU
1. Klasse kompilieren (Uebersetzen).
2. Rechtsklick auf Pruefstand -> allesPruefen(): Im Terminal erscheint die Testtabelle.
3. Die Stellen mit "TODO Aufgabe x.y" in Reihenfolge bearbeiten, nach jeder Aufgabe neu pruefen.
4. Ziel (Plateau): alle Tests ausser "Expert" bestehen.

AUFGABEN STUFE 3 (Vererbung)
Fahrzeug ist jetzt abstrakt. Sportwagen ist die fertige Musterklasse - lies sie zuerst.
3.1 Van: Konstruktor ergaenzen (super(...) steht schon da).
3.2 Van: gibTyp() ueberschreiben.
3.3 Van: einsteigen(int pAnzahl) - hoechstens so viele, wie Sitze frei sind.
3.4 Van: alleAussteigen().
3.5 Van: berechneMiete() MIT super (Grundmiete + 5 Euro je Mitfahrer).
3.6 Van: anzeigen() MIT super.
3.7 Speedboot: berechneMiete() OHNE super (200 + 2 Euro je Liter im Tank).
Rover-Bezug: In Greenfoot gilt "Rover extends Actor" - der Rover erbt von Actor.

