/**
 * Abstrakte Oberklasse fuer alle Mietfahrzeuge von "Palm Bay Rentals".
 *
 * Stufe 3: Vererbung.
 * Alles, was JEDES Fahrzeug kann (fahren, Fahrzeit berechnen), steht hier.
 * Was nur ein Sportwagen, ein Van oder ein Speedboot kann, steht in der
 * jeweiligen Unterklasse.
 * (Beim Marsrover: Rover extends Actor - der Rover erbt z. B. move() und
 * turn() von der Greenfoot-Klasse Actor.)
 *
 * "abstract" heisst: Es gibt kein Objekt, das NUR ein Fahrzeug ist.
 * Man kann also nicht new Fahrzeug(...) schreiben, sondern nur
 * new Sportwagen(...), new Van(...) oder new Speedboot(...).
 */
public abstract class Fahrzeug
{
    private String name;
    private int position;
    private int geschwindigkeit;

    /**
     * Wird von den Unterklassen mit super(pName, pGeschwindigkeit) aufgerufen.
     *
     * @param pName Name des Fahrzeuges
     * @param pGeschwindigkeit Geschwindigkeit in km/h
     */
    public Fahrzeug(String pName, int pGeschwindigkeit)
    {
        name = pName;
        geschwindigkeit = pGeschwindigkeit;
        position = 0;
    }

    /** @return Name des Fahrzeuges */
    public String gibName()
    {
        return name;
    }

    /** @return aktuelle Position in Blocks ab Garage */
    public int gibPosition()
    {
        return position;
    }

    /** @return Geschwindigkeit in km/h */
    public int gibGeschwindigkeit()
    {
        return geschwindigkeit;
    }

    /** Das Fahrzeug faehrt einen Block weiter. */
    public void fahre()
    {
        position = position + 1;
    }

    /**
     * Das Fahrzeug faehrt pAnzahl Blocks weiter.
     *
     * @param pAnzahl Anzahl Blocks
     */
    public void fahreBloecke(int pAnzahl)
    {
        for (int i = 0; i < pAnzahl; i++)
        {
            fahre();
        }
    }

    /** Das Fahrzeug faehrt zurueck in die Garage. */
    public void kehreZurueck()
    {
        position = 0;
    }

    /** @return true, wenn das Fahrzeug in der Garage liegt */
    public boolean istInGarage()
    {
        return position == 0;
    }

    /**
     * Fahrzeit in vollen Stunden (angefangene Stunden zaehlen voll).
     *
     * @param pKilometer Laenge der Strecke
     * @return Fahrzeit in Stunden
     */
    public int berechneFahrzeit(int pKilometer)
    {
        int rest = pKilometer;
        int stunden = 0;
        while (rest > 0)
        {
            rest = rest - geschwindigkeit;
            stunden++;
        }
        return stunden;
    }

    /**
     * Abstrakte Methode: Jede Unterklasse MUSS sagen, welcher Typ sie ist.
     *
     * @return Typbezeichnung, z. B. "Sportwagen"
     */
    public abstract String gibTyp();

    /**
     * Tagesmiete in Euro. Jedes Fahrzeug kostet mindestens die
     * Grundmiete von 50 Euro. Unterklassen erweitern das.
     *
     * @return Tagesmiete in Euro
     */
    public int berechneMiete()
    {
        return 50;
    }

    /** Gibt die Daten aus, die jedes Fahrzeug hat. */
    public void anzeigen()
    {
        System.out.println(gibTyp() + " " + name + ": Block " + position
            + ", " + geschwindigkeit + " km/h, Tagesmiete "
            + berechneMiete() + " Euro");
    }
}
