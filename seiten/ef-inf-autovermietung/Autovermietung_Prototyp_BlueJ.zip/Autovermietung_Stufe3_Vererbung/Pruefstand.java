/**
 * Pruefstand fuer Stufe 3.
 *
 * Rechtsklick auf die Klasse Pruefstand -> allesPruefen() ausfuehren.
 */
public class Pruefstand
{
    private static int bestanden;
    private static int gesamt;

    /**
     * Fuehrt alle Testfaelle der Stufe 3 aus.
     */
    public static void allesPruefen()
    {
        start("Stufe 3: Vererbung");
        Sportwagen s = new Sportwagen("Flamingo GT", 140, 420);
        pruefe("Sportwagen: gibTyp()", "Sportwagen", s.gibTyp());
        pruefe("Sportwagen 420 PS: Miete", 260, s.berechneMiete());
        s.fahreBloecke(3);
        pruefe("Sportwagen erbt fahreBloecke(3)", 3, s.gibPosition());

        Van v = new Van("Beach Van", 80, 9);
        pruefe("Van: gibSitze()", 9, v.gibSitze());
        pruefe("Van: gibTyp()", "Van", v.gibTyp());
        pruefe("einsteigen(6) liefert", 6, v.einsteigen(6));
        pruefe("einsteigen(6) bei 3 frei liefert", 3, v.einsteigen(6));
        pruefe("danach gibMitfahrer()", 9, v.gibMitfahrer());
        pruefe("Van mit 9 Mitfahrern: Miete", 95, v.berechneMiete());
        pruefe("alleAussteigen() liefert", 9, v.alleAussteigen());
        pruefe("danach Miete (nur Grundmiete)", 50, v.berechneMiete());
        pruefe("Van erbt berechneFahrzeit(161)", 3, v.berechneFahrzeit(161));

        Speedboot b = new Speedboot("Coral Runner", 60, 200);
        b.tanken(80);
        pruefe("Speedboot: gibTyp()", "Speedboot", b.gibTyp());
        pruefe("Speedboot mit 80 l: Miete (ohne super)", 360, b.berechneMiete());

        // Polymorphie: Variable vom Typ Fahrzeug, Objekt vom Typ Van
        Fahrzeug f = new Van("Party Van", 70, 7);
        pruefe("Fahrzeug f = new Van(...): f.gibTyp()", "Van", f.gibTyp());
        ende();
    }

    // ---------- Hilfsmethoden fuer die Testtabelle ----------

    private static void start(String pTitel)
    {
        bestanden = 0;
        gesamt = 0;
        System.out.println("=== " + pTitel + " ===");
        System.out.println(spalte("Testfall", 42) + spalte("erwartet", 10) + spalte("erhalten", 10) + "ok");
    }

    private static void pruefe(String pFall, Object pErwartet, Object pErhalten)
    {
        gesamt++;
        boolean ok = String.valueOf(pErwartet).equals(String.valueOf(pErhalten));
        if (ok)
        {
            bestanden++;
        }
        System.out.println(spalte(pFall, 42) + spalte(String.valueOf(pErwartet), 10)
            + spalte(String.valueOf(pErhalten), 10) + (ok ? "ja" : "NEIN"));
    }

    private static void ende()
    {
        System.out.println("--> " + bestanden + " von " + gesamt + " Tests bestanden");
        System.out.println();
    }

    private static String spalte(String pText, int pBreite)
    {
        String t = pText;
        while (t.length() < pBreite)
        {
            t = t + " ";
        }
        return t + " ";
    }

    /** Start ausserhalb von BlueJ. */
    public static void main(String[] args)
    {
        allesPruefen();
    }
}
