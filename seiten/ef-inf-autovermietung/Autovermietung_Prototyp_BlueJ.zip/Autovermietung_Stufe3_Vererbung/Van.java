/**
 * Ein Van (Kleinbus) fuer Gruppen: Er nimmt Mitfahrer mit.
 *
 * Stufe 3: Ergaenze die Klasse nach dem Vorbild von Sportwagen.
 */
public class Van extends Fahrzeug
{
    private int mitfahrer;
    private int sitze;

    /**
     * Erzeugt einen leeren Van in der Garage.
     *
     * @param pName Name des Fahrzeuges
     * @param pGeschwindigkeit Geschwindigkeit in km/h
     * @param pSitze Anzahl Sitze fuer Mitfahrer
     */
    public Van(String pName, int pGeschwindigkeit, int pSitze)
    {
        super(pName, pGeschwindigkeit);
        // TODO Aufgabe 3.1: Setze sitze auf den Parameterwert und mitfahrer auf 0.
    }

    /** @return Anzahl Mitfahrer im Van */
    public int gibMitfahrer()
    {
        return mitfahrer;
    }

    /** @return Anzahl Sitze fuer Mitfahrer */
    public int gibSitze()
    {
        return sitze;
    }

    /**
     * Pflicht-Override.
     *
     * @return "Van"
     */
    @Override
    public String gibTyp()
    {
        // TODO Aufgabe 3.2: Gib die Typbezeichnung "Van" zurueck.
        return "";  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * Laesst hoechstens pAnzahl Mitfahrer einsteigen, soweit Platz ist.
     *
     * @param pAnzahl Anzahl der Wartenden
     * @return Anzahl der tatsaechlich eingestiegenen Mitfahrer
     */
    public int einsteigen(int pAnzahl)
    {
        // TODO Aufgabe 3.3: Berechne, wie viele einsteigen koennen, erhoehe mitfahrer und gib die Zahl zurueck.
        return 0;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * Alle Mitfahrer steigen aus.
     *
     * @return Anzahl der ausgestiegenen Mitfahrer
     */
    public int alleAussteigen()
    {
        // TODO Aufgabe 3.4: Merke dir die Anzahl, setze mitfahrer auf 0 und gib die gemerkte Anzahl zurueck.
        return 0;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * Override MIT super: Grundmiete plus 5 Euro je Mitfahrer.
     *
     * @return Tagesmiete in Euro
     */
    @Override
    public int berechneMiete()
    {
        // TODO Aufgabe 3.5: Nutze super.berechneMiete() wie im Sportwagen.
        return 0;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /** Override MIT super: erst die Fahrzeugdaten, dann die Mitfahrer. */
    @Override
    public void anzeigen()
    {
        // TODO Aufgabe 3.6: Rufe zuerst super.anzeigen() auf und gib dann die Mitfahrer aus.
    }
}
