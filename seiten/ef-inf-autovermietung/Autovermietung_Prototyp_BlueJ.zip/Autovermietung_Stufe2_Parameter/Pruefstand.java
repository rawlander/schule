/**
 * Pruefstand fuer Stufe 2.
 *
 * Rechtsklick auf die Klasse Pruefstand -> allesPruefen() ausfuehren.
 */
public class Pruefstand
{
    private static int bestanden;
    private static int gesamt;

    /**
     * Fuehrt alle Testfaelle der Stufe 2 aus.
     */
    public static void allesPruefen()
    {
        start("Stufe 2: Parameter und Rueckgabewerte");
        Auto a = new Auto("Flamingo GT", 10, 60);
        a.fahreBloecke(5);
        pruefe("fahreBloecke(5): gibPosition()", 5, a.gibPosition());
        a.fahreBloecke(0);
        pruefe("fahreBloecke(0): Position bleibt", 5, a.gibPosition());

        pruefe("leer, 10 Balken: gibFreieBalken()", 10, a.gibFreieBalken());
        pruefe("ladeBalken(4) liefert", 4, a.ladeBalken(4));
        pruefe("danach gibFreieBalken()", 6, a.gibFreieBalken());
        pruefe("ladeBalken(9) bei 6 frei liefert", 6, a.ladeBalken(9));
        pruefe("danach gibAkku()", 10, a.gibAkku());
        pruefe("ladeBalken(3) wenn voll liefert", 0, a.ladeBalken(3));

        pruefe("verbraucheBalken(4) liefert", 4, a.verbraucheBalken(4));
        pruefe("verbraucheBalken(20) bei 6 Balken", 6, a.verbraucheBalken(20));
        pruefe("danach istLeer()", true, a.istLeer());

        pruefe("berechneFahrzeit(120) bei 60 km/h", 2, a.berechneFahrzeit(120));
        pruefe("berechneFahrzeit(121) bei 60 km/h", 3, a.berechneFahrzeit(121));
        pruefe("berechneFahrzeit(1) bei 60 km/h", 1, a.berechneFahrzeit(1));
        pruefe("berechneFahrzeit(0) bei 60 km/h", 0, a.berechneFahrzeit(0));

        pruefe("Expert: schafftStrecke(180, 3)", true, a.schafftStrecke(180, 3));
        pruefe("Expert: schafftStrecke(181, 3)", false, a.schafftStrecke(181, 3));
        ende();
    }

    // ---------- Hilfsmethoden fuer die Testtabelle ----------

    private static void start(String pTitel)
    {
        bestanden = 0;
        gesamt = 0;
        System.out.println("=== " + pTitel + " ===");
        System.out.println(spalte("Testfall", 42) + spalte("erwartet", 10) + spalte("erhalten", 10) + "ok");
    }

    private static void pruefe(String pFall, Object pErwartet, Object pErhalten)
    {
        gesamt++;
        boolean ok = String.valueOf(pErwartet).equals(String.valueOf(pErhalten));
        if (ok)
        {
            bestanden++;
        }
        System.out.println(spalte(pFall, 42) + spalte(String.valueOf(pErwartet), 10)
            + spalte(String.valueOf(pErhalten), 10) + (ok ? "ja" : "NEIN"));
    }

    private static void ende()
    {
        System.out.println("--> " + bestanden + " von " + gesamt + " Tests bestanden");
        System.out.println();
    }

    private static String spalte(String pText, int pBreite)
    {
        String t = pText;
        while (t.length() < pBreite)
        {
            t = t + " ";
        }
        return t + " ";
    }

    /** Start ausserhalb von BlueJ. */
    public static void main(String[] args)
    {
        allesPruefen();
    }
}
