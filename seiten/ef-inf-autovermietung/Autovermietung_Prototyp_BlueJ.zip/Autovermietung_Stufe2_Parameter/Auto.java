/**
 * Ein E-Mietwagen der Autovermietung "Palm Bay Rentals".
 *
 * Stufe 2: Parameter und Rueckgabewerte.
 * Wie beim Rover mit fahreSchritte(int pAnzahl) bekommt das Auto
 * Werte von aussen (Parameter) und liefert Ergebnisse zurueck
 * (Rueckgabewert), z. B. wie viele Balken wirklich geladen wurden.
 *
 * Neu ist das Attribut geschwindigkeit (in km/h).
 */
public class Auto
{
    private String name;
    private int position;
    private int akku;
    private int akkuGroesse;
    private int geschwindigkeit;

    /**
     * Erzeugt ein Auto mit leerem Akku in der Garage.
     *
     * @param pName Modellname des Autos
     * @param pAkkuGroesse maximale Anzahl Akku-Balken
     * @param pGeschwindigkeit Reisegeschwindigkeit in km/h
     */
    public Auto(String pName, int pAkkuGroesse, int pGeschwindigkeit)
    {
        name = pName;
        akkuGroesse = pAkkuGroesse;
        geschwindigkeit = pGeschwindigkeit;
        position = 0;
        akku = 0;
    }

    // ---------- Getter ----------

    /** @return Modellname des Autos */
    public String gibName()
    {
        return name;
    }

    /** @return aktueller Block (0 = Garage) */
    public int gibPosition()
    {
        return position;
    }

    /** @return Anzahl geladener Akku-Balken */
    public int gibAkku()
    {
        return akku;
    }

    /** @return maximale Anzahl Akku-Balken */
    public int gibAkkuGroesse()
    {
        return akkuGroesse;
    }

    /** @return Reisegeschwindigkeit in km/h */
    public int gibGeschwindigkeit()
    {
        return geschwindigkeit;
    }

    // ---------- Auftraege aus Stufe 1 ----------

    /** Das Auto faehrt einen Block weiter. */
    public void fahre()
    {
        position = position + 1;
    }

    /** Das Auto faehrt zurueck in die Garage. */
    public void kehreZurueck()
    {
        position = 0;
    }

    /** Laedt einen Balken, falls der Akku nicht voll ist. */
    public void ladeBalken()
    {
        if (!istVoll())
        {
            akku = akku + 1;
        }
    }

    /** Verbraucht einen Balken, falls der Akku nicht leer ist. */
    public void verbraucheBalken()
    {
        if (!istLeer())
        {
            akku = akku - 1;
        }
    }

    // ---------- Anfragen aus Stufe 1 ----------

    /** @return true, wenn das Auto in der Garage steht */
    public boolean istInGarage()
    {
        return position == 0;
    }

    /** @return true, wenn der Akku voll ist */
    public boolean istVoll()
    {
        return akku >= akkuGroesse;
    }

    /** @return true, wenn der Akku leer ist */
    public boolean istLeer()
    {
        return akku == 0;
    }

    // ---------- NEU: Parameter ----------

    /**
     * Das Auto faehrt pAnzahl Blocks weiter.
     * (Beim Rover: fahreSchritte(int pAnzahl).)
     *
     * @param pAnzahl Anzahl Blocks
     */
    public void fahreBloecke(int pAnzahl)
    {
        // TODO Aufgabe 2.1: Rufe mit einer for-Schleife pAnzahl-mal fahre() auf.
    }

    // ---------- NEU: Rueckgabewerte ----------

    /**
     * @return Anzahl der noch freien Akku-Balken
     */
    public int gibFreieBalken()
    {
        // TODO Aufgabe 2.2: Gib zurueck, wie viele Balken noch frei sind (akkuGroesse minus akku).
        return 0;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * Laedt pAnzahl Balken, aber nur so viele, wie frei sind.
     * (Beim Rover: fahreHoechstens(int pMax) liefert die gefahrenen Schritte.)
     *
     * @param pAnzahl Anzahl Balken, die geladen werden sollen
     * @return Anzahl Balken, die tatsaechlich geladen wurden
     */
    public int ladeBalken(int pAnzahl)
    {
        // TODO Aufgabe 2.3: Lade hoechstens pAnzahl Balken (nur solange der Akku nicht voll ist) und zaehle mit. Gib die Anzahl zurueck.
        return 0;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * Verbraucht pAnzahl Balken, aber hoechstens so viele, wie geladen sind.
     *
     * @param pAnzahl Anzahl Balken, die verbraucht werden sollen
     * @return Anzahl Balken, die tatsaechlich verbraucht wurden
     */
    public int verbraucheBalken(int pAnzahl)
    {
        // TODO Aufgabe 2.4: Wie 2.3, nur zum Verbrauchen.
        return 0;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * Berechnet, wie viele volle Stunden das Auto fuer pKilometer braucht.
     * Angefangene Stunden zaehlen als volle Stunde (so wird die Miete berechnet).
     * Beispiel: 121 km bei 60 km/h -> 3 Stunden.
     *
     * @param pKilometer Laenge der Strecke
     * @return Fahrzeit in vollen Stunden
     */
    public int berechneFahrzeit(int pKilometer)
    {
        // TODO Aufgabe 2.5: Zaehle Stunden: Ziehe so lange die Geschwindigkeit von der Reststrecke ab, bis nichts mehr uebrig ist.
        return 0;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * Expert: Schafft das Auto die Strecke in der vorgegebenen Zeit?
     *
     * @param pKilometer Laenge der Strecke
     * @param pStunden verfuegbare Zeit in Stunden
     * @return true, wenn die Fahrzeit hoechstens pStunden betraegt
     */
    public boolean schafftStrecke(int pKilometer, int pStunden)
    {
        // TODO Aufgabe 2.6: Expert: Nutze berechneFahrzeit(...) und vergleiche.
        return false;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /** Gibt alle Daten des Autos aus. */
    public void anzeigen()
    {
        System.out.println(name + ": Block " + position
            + ", Akku " + akku + "/" + akkuGroesse + " Balken, "
            + geschwindigkeit + " km/h");
    }
}
