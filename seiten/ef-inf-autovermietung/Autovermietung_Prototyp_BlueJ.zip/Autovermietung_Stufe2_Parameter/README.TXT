Projekt: Palm Bay Rentals (Autovermietung) - Stufe 2: Parameter und Rueckgabewerte
Kurs: Informatik EF (NRW), Bischoefliches St.-Josef-Gymnasium Bocholt
Fassung: Schuelerfassung mit Luecken

Vom Marsrover zur Autovermietung: Was ihr mit dem Rover in Greenfoot gelernt habt
(Auftraege, Anfragen, Parameter, Rueckgabe), wendet ihr hier in reinem Java an.

SO ARBEITEST DU
1. Klasse kompilieren (Uebersetzen).
2. Rechtsklick auf Pruefstand -> allesPruefen(): Im Terminal erscheint die Testtabelle.
3. Die Stellen mit "TODO Aufgabe x.y" in Reihenfolge bearbeiten, nach jeder Aufgabe neu pruefen.
4. Ziel (Plateau): alle Tests ausser "Expert" bestehen.

AUFGABEN STUFE 2 (Klasse Auto, neues Attribut geschwindigkeit)
2.1 fahreBloecke(int pAnzahl): for-Schleife.                  (Rover: fahreSchritte(int pAnzahl))
2.2 gibFreieBalken(): int zurueckgeben.
2.3 ladeBalken(int pAnzahl): hoechstens so viele laden, wie frei sind; Anzahl zurueckgeben.
                                                              (Rover: fahreHoechstens(int pMax))
2.4 verbraucheBalken(int pAnzahl): wie 2.3 zum Verbrauchen.
2.5 berechneFahrzeit(int pKilometer): angefangene Stunden zaehlen voll.
2.6 Expert: schafftStrecke(int pKilometer, int pStunden).
Hinweis: Es gibt jetzt zwei Methoden ladeBalken - mit und ohne Parameter (Ueberladen).

