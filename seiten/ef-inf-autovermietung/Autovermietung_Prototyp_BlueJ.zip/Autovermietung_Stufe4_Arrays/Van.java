/**
 * Ein Van (Kleinbus) fuer Gruppen: Er nimmt Mitfahrer mit.
 *
 * Stufe 3: Ergaenze die Klasse nach dem Vorbild von Sportwagen.
 */
public class Van extends Fahrzeug
{
    private int mitfahrer;
    private int sitze;

    /**
     * Erzeugt einen leeren Van in der Garage.
     *
     * @param pName Name des Fahrzeuges
     * @param pGeschwindigkeit Geschwindigkeit in km/h
     * @param pSitze Anzahl Sitze fuer Mitfahrer
     */
    public Van(String pName, int pGeschwindigkeit, int pSitze)
    {
        super(pName, pGeschwindigkeit);
        sitze = pSitze;
        mitfahrer = 0;
    }

    /** @return Anzahl Mitfahrer im Van */
    public int gibMitfahrer()
    {
        return mitfahrer;
    }

    /** @return Anzahl Sitze fuer Mitfahrer */
    public int gibSitze()
    {
        return sitze;
    }

    /**
     * Pflicht-Override.
     *
     * @return "Van"
     */
    @Override
    public String gibTyp()
    {
        return "Van";
    }

    /**
     * Laesst hoechstens pAnzahl Mitfahrer einsteigen, soweit Platz ist.
     *
     * @param pAnzahl Anzahl der Wartenden
     * @return Anzahl der tatsaechlich eingestiegenen Mitfahrer
     */
    public int einsteigen(int pAnzahl)
    {
        int frei = sitze - mitfahrer;
        int rein = pAnzahl;
        if (rein > frei)
        {
            rein = frei;
        }
        mitfahrer = mitfahrer + rein;
        return rein;
    }

    /**
     * Alle Mitfahrer steigen aus.
     *
     * @return Anzahl der ausgestiegenen Mitfahrer
     */
    public int alleAussteigen()
    {
        int raus = mitfahrer;
        mitfahrer = 0;
        return raus;
    }

    /**
     * Override MIT super: Grundmiete plus 5 Euro je Mitfahrer.
     *
     * @return Tagesmiete in Euro
     */
    @Override
    public int berechneMiete()
    {
        return super.berechneMiete() + 5 * mitfahrer;
    }

    /** Override MIT super: erst die Fahrzeugdaten, dann die Mitfahrer. */
    @Override
    public void anzeigen()
    {
        super.anzeigen();
        System.out.println("   Mitfahrer: " + mitfahrer + "/" + sitze);
    }
}
