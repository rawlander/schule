/**
 * Die Autovermietung verwaltet ihre Flotte in einem Array.
 *
 * Stufe 4: Arrays.
 * Ein Array ist eine nummerierte Reihe von Faechern. Jedes Fach
 * kann ein Fahrzeug aufnehmen - egal ob Sportwagen, Van oder Speedboot,
 * denn alle SIND Fahrzeuge (Vererbung aus Stufe 3).
 * (Beim Marsrover gab es genau einen Rover. Jetzt verwalten wir viele.)
 *
 *   flotte:  [0]      [1]      [2]     [3]    ...  [9]
 *            Flamingo  Beach V. Coral   null        null
 *   anzahl = 3  (die naechste freie Stelle ist flotte[3])
 */
public class Autovermietung
{
    private String name;
    private Fahrzeug[] flotte;
    private int anzahl;

    /**
     * Erzeugt eine Autovermietung ohne Fahrzeuge mit Platz fuer pMaxFahrzeuge.
     *
     * @param pName Name der Autovermietung
     * @param pMaxFahrzeuge Groesse des Arrays
     */
    public Autovermietung(String pName, int pMaxFahrzeuge)
    {
        name = pName;
        flotte = new Fahrzeug[pMaxFahrzeuge];
        anzahl = 0;
    }

    /** @return Name der Autovermietung */
    public String gibName()
    {
        return name;
    }

    /** @return Anzahl der Fahrzeuge in der Flotte */
    public int gibAnzahl()
    {
        return anzahl;
    }

    /**
     * @param pIndex Platz im Array (0 bis gibAnzahl() - 1)
     * @return Fahrzeug an dieser Stelle oder null, wenn der Index ungueltig ist
     */
    public Fahrzeug gibFahrzeug(int pIndex)
    {
        if (pIndex >= 0 && pIndex < anzahl)
        {
            return flotte[pIndex];
        }
        return null;
    }

    /**
     * Nimmt ein Fahrzeug in die Flotte auf, falls noch Platz ist.
     *
     * @param pFahrzeug neues Fahrzeug
     * @return true, wenn das Fahrzeug aufgenommen wurde
     */
    public boolean hinzufuegen(Fahrzeug pFahrzeug)
    {
        // TODO Aufgabe 4.1: Ist noch Platz (anzahl < flotte.length)? Dann Fahrzeug an Stelle anzahl speichern, anzahl erhoehen, true zurueckgeben.
        return false;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * Beispiel: Alle Fahrzeuge durchlaufen und anzeigen.
     * Jedes Fahrzeug zeigt sich so an, wie es seine Klasse vorsieht
     * (Polymorphie).
     */
    public void alleAnzeigen()
    {
        System.out.println("=== Flotte der " + name + " (" + anzahl + " Fahrzeuge) ===");
        for (int i = 0; i < anzahl; i++)
        {
            flotte[i].anzeigen();
        }
    }

    /**
     * Alle Fahrzeuge fahren pBloecke weiter.
     *
     * @param pBloecke Anzahl Blocks fuer jedes Fahrzeug
     */
    public void alleFahren(int pBloecke)
    {
        // TODO Aufgabe 4.2: Durchlaufe die Flotte und rufe fuer jedes Fahrzeug fahreBloecke(pBloecke) auf.
    }

    /**
     * Summe der Tagesmieten aller Fahrzeuge.
     *
     * @return Gesamtmiete in Euro
     */
    public int berechneGesamtmiete()
    {
        // TODO Aufgabe 4.3: Summiere berechneMiete() ueber alle Fahrzeuge (Akkumulator wie bei schritteBisHuegel).
        return 0;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * Zaehlt die Fahrzeuge eines Typs.
     *
     * @param pTyp z. B. "Van"
     * @return Anzahl der Fahrzeuge mit diesem Typ
     */
    public int zaehleTyp(String pTyp)
    {
        // TODO Aufgabe 4.4: Zaehle alle Fahrzeuge, deren gibTyp() gleich pTyp ist. Strings mit equals vergleichen!
        return 0;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * Lineare Suche nach dem Namen.
     *
     * @param pName gesuchter Name
     * @return das Fahrzeug oder null, wenn es keins mit diesem Namen gibt
     */
    public Fahrzeug sucheFahrzeug(String pName)
    {
        // TODO Aufgabe 4.5: Durchlaufe die Flotte; bei Treffer sofort das Fahrzeug zurueckgeben, nach der Schleife null.
        return null;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * Sucht das schnellste Fahrzeug (Maximumsuche).
     *
     * @return schnellstes Fahrzeug oder null bei leerer Flotte
     */
    public Fahrzeug gibSchnellstesFahrzeug()
    {
        // TODO Aufgabe 4.6: Maximumsuche: Merke dir das erste Fahrzeug als bestes und vergleiche mit allen weiteren.
        return null;  // Platzhalter, damit es kompiliert - ersetzen!
    }

    /**
     * Expert: Sortiert die Flotte absteigend nach Geschwindigkeit
     * (Bubblesort: benachbarte Fahrzeuge vertauschen, wenn das hintere schneller ist).
     */
    public void sortiereNachGeschwindigkeit()
    {
        // TODO Aufgabe 4.7: Expert: Bubblesort auf flotte[0] bis flotte[anzahl - 1].
    }

    /**
     * Erzeugt eine Beispiel-Vermietung mit vier Fahrzeugen zum Ausprobieren.
     * In BlueJ: Rechtsklick auf Autovermietung -> beispielflotte().
     *
     * @return "Palm Bay Rentals" mit 4 Fahrzeugen
     */
    public static Autovermietung beispielflotte()
    {
        Autovermietung v = new Autovermietung("Palm Bay Rentals", 10);
        Sportwagen flamingo = new Sportwagen("Flamingo GT", 140, 420);
        Van van = new Van("Beach Van", 80, 9);
        van.einsteigen(6);
        Speedboot boot = new Speedboot("Coral Runner", 60, 200);
        boot.tanken(80);
        Sportwagen cruiser = new Sportwagen("Night Cruiser", 110, 300);
        v.hinzufuegen(flamingo);
        v.hinzufuegen(van);
        v.hinzufuegen(boot);
        v.hinzufuegen(cruiser);
        return v;
    }

    /** Gibt die Kurzdaten der Autovermietung aus. */
    public void anzeigen()
    {
        System.out.println(name + ": " + anzahl + " von " + flotte.length + " Stellplaetzen belegt");
    }
}
