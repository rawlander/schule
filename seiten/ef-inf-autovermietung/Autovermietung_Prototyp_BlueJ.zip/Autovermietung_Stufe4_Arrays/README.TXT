Projekt: Palm Bay Rentals (Autovermietung) - Stufe 4: Arrays (Verwaltungsklasse, Durchlaufen, Suchen, Maximum)
Kurs: Informatik EF (NRW), Bischoefliches St.-Josef-Gymnasium Bocholt
Fassung: Schuelerfassung mit Luecken

Vom Marsrover zur Autovermietung: Was ihr mit dem Rover in Greenfoot gelernt habt
(Auftraege, Anfragen, Parameter, Rueckgabe), wendet ihr hier in reinem Java an.

SO ARBEITEST DU
1. Klasse kompilieren (Uebersetzen).
2. Rechtsklick auf Pruefstand -> allesPruefen(): Im Terminal erscheint die Testtabelle.
3. Die Stellen mit "TODO Aufgabe x.y" in Reihenfolge bearbeiten, nach jeder Aufgabe neu pruefen.
4. Ziel (Plateau): alle Tests ausser "Expert" bestehen.

AUFGABEN STUFE 4 (Klasse Autovermietung mit Fahrzeug[] flotte)
4.1 hinzufuegen(Fahrzeug pFahrzeug): an Stelle anzahl einfuegen, wenn Platz ist.
4.2 alleFahren(int pBloecke): Array durchlaufen.
4.3 berechneGesamtmiete(): Summe (Akkumulator).
4.4 zaehleTyp(String pTyp): Zaehlen mit Bedingung (equals!).
4.5 sucheFahrzeug(String pName): lineare Suche.
4.6 gibSchnellstesFahrzeug(): Maximumsuche.
4.7 Expert: sortiereNachGeschwindigkeit() mit Bubblesort.
Ausprobieren: Rechtsklick auf Autovermietung -> beispielflotte(), dann alleAnzeigen().
Beachte Polymorphie: Jedes Fahrzeug zeigt sich mit SEINER anzeigen()-Methode.

