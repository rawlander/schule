/**
 * Pruefstand fuer Stufe 4.
 *
 * Rechtsklick auf die Klasse Pruefstand -> allesPruefen() ausfuehren.
 */
public class Pruefstand
{
    private static int bestanden;
    private static int gesamt;

    /**
     * Fuehrt alle Testfaelle der Stufe 4 aus.
     */
    public static void allesPruefen()
    {
        start("Stufe 4: Arrays");
        Autovermietung klein = new Autovermietung("Mini", 2);
        pruefe("hinzufuegen (Platz frei) liefert", true, klein.hinzufuegen(new Sportwagen("A", 100, 200)));
        klein.hinzufuegen(new Sportwagen("B", 100, 200));
        pruefe("hinzufuegen (Array voll) liefert", false, klein.hinzufuegen(new Sportwagen("C", 100, 200)));
        pruefe("danach gibAnzahl()", 2, klein.gibAnzahl());

        Autovermietung r = Autovermietung.beispielflotte();
        pruefe("beispielflotte: gibAnzahl()", 4, r.gibAnzahl());
        pruefe("berechneGesamtmiete()", 900, r.berechneGesamtmiete());
        pruefe("zaehleTyp(\"Sportwagen\")", 2, r.zaehleTyp("Sportwagen"));
        pruefe("zaehleTyp(\"Hubschrauber\")", 0, r.zaehleTyp("Hubschrauber"));

        Fahrzeug gefunden = r.sucheFahrzeug("Coral Runner");
        pruefe("sucheFahrzeug(\"Coral Runner\"): gibTyp()", "Speedboot", gefunden == null ? "null" : gefunden.gibTyp());
        pruefe("sucheFahrzeug(\"Wunderauto\")", "null", String.valueOf(r.sucheFahrzeug("Wunderauto")));

        Fahrzeug schnell = r.gibSchnellstesFahrzeug();
        pruefe("gibSchnellstesFahrzeug(): gibName()", "Flamingo GT", schnell == null ? "null" : schnell.gibName());
        pruefe("leere Autovermietung: gibSchnellstesFahrzeug()", "null", String.valueOf(new Autovermietung("Leer", 3).gibSchnellstesFahrzeug()));

        r.alleFahren(5);
        Fahrzeug letztes = r.gibFahrzeug(3);
        pruefe("alleFahren(5): Position von Fahrzeug 3", 5, letztes == null ? "kein Fahrzeug" : String.valueOf(letztes.gibPosition()));

        r.sortiereNachGeschwindigkeit();
        String reihe = "";
        for (int i = 0; i < r.gibAnzahl(); i++)
        {
            reihe = reihe + r.gibFahrzeug(i).gibGeschwindigkeit() + " ";
        }
        pruefe("Expert: sortiert (Knoten)", "140 110 80 60 ", reihe);
        ende();
    }

    // ---------- Hilfsmethoden fuer die Testtabelle ----------

    private static void start(String pTitel)
    {
        bestanden = 0;
        gesamt = 0;
        System.out.println("=== " + pTitel + " ===");
        System.out.println(spalte("Testfall", 42) + spalte("erwartet", 10) + spalte("erhalten", 10) + "ok");
    }

    private static void pruefe(String pFall, Object pErwartet, Object pErhalten)
    {
        gesamt++;
        boolean ok = String.valueOf(pErwartet).equals(String.valueOf(pErhalten));
        if (ok)
        {
            bestanden++;
        }
        System.out.println(spalte(pFall, 42) + spalte(String.valueOf(pErwartet), 10)
            + spalte(String.valueOf(pErhalten), 10) + (ok ? "ja" : "NEIN"));
    }

    private static void ende()
    {
        System.out.println("--> " + bestanden + " von " + gesamt + " Tests bestanden");
        System.out.println();
    }

    private static String spalte(String pText, int pBreite)
    {
        String t = pText;
        while (t.length() < pBreite)
        {
            t = t + " ";
        }
        return t + " ";
    }

    /** Start ausserhalb von BlueJ. */
    public static void main(String[] args)
    {
        allesPruefen();
    }
}
